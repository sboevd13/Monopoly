package com.srvr.serverForGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerForGameApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerForGameApplication.class, args);
    }

}
