package com.srvr.serverForGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerForGameApplicationTests {

    @Test
    void contextLoads() {
    }

}
